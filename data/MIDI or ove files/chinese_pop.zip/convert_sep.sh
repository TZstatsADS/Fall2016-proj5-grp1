#!/bin/bash

i="1"
for file in $(ls | grep .mid)
do
   midi2abc $file -o $i.txt
   i=$(($i+1))
done
